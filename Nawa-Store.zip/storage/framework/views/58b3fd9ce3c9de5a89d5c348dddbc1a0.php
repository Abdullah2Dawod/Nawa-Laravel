<?php $__env->startSection('sub_title' , 'Orders'); ?>

<?php $__env->startSection('content'); ?>


<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"><?php echo e($title); ?> </h2>
</header>

<div class="row">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</div>
<table class="table table-striped">
    <thead>
        <tr class="table-dark">
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Subject</th>
            <th>Message</th>
            <th>Delete</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($message->id); ?></td>
                <td><?php echo e($message->name); ?> </td>
                <td><?php echo e($message->email); ?> </td>
                <td><?php echo e($message->phone); ?> </td>
                <td><?php echo e($message->subject); ?> </td>
                <td><?php echo e($message->message); ?> </td>
                <td>
                    <form action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger"><i
                                class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($messages->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>