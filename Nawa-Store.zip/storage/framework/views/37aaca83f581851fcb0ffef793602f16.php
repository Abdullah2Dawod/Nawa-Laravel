<?php $__env->startSection('sub_title' , 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"><?php echo e($title); ?> </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('products.create')); ?>" type="button" class="btn btn-info p-2">Create Proudct
                <i class="fas fa-plus"></i></a>
            <a href="<?php echo e(route('products.trashed')); ?>" type="button" class="btn btn-danger p-2">Products Trashed
                <i class="fas fa-trash-alt"></i></a>
        </div>
    </header>
    <hr>

    <div class="row">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(URL::current()); ?>" method="get" class="form-inline">
        <input type="text" name="search" class="form-control mb-2 mr-sm-2" value="<?php echo e(request('saerch')); ?>" placeholder="Search...">
        <select name="category_id" class="form-control mb-2 mr-sm-2">
            <option value="">All Categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if(request('$category->id') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="status" class="form-control mb-2 mr-sm-2">
            <option value="">Status</option>
            <?php $__currentLoopData = $status_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $kay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if(request('status') == $value): echo 'selected'; endif; ?>><?php echo e($kay); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="number" name="price_min" class="form-control mb-2 mr-sm-2" value="<?php echo e(request('price_min')); ?>" placeholder="Min Price">
        <input type="number" name="price_max" class="form-control mb-2 mr-sm-2" value="<?php echo e(request('price_max')); ?>" placeholder="Max Price">
        <button type="submit" class="btn btn-success mb-2 mr-sm-2" style="border: none">Search</button>
    </form>
    <table class="table table-striped text-center mt-2">
        <thead>
            <tr class="table-dark">
                <th>Id</th>
                <th>Images</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <th>
                        <a href="<?php echo e($product->image_url); ?>">
                            <img src="<?php echo e($product->image_url); ?>" width="60" alt="">
                        </a>
                    </th>
                    
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->category_name); ?></td>
                    <td><?php echo e($product->price_formatted); ?></td>
                    <td><?php echo e($product->status); ?></td>
                    <td><a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn-sm btn btn-outline-secondary"><i
                                class="far fa-edit"></i< /a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i
                                    class="fas fa-trash"></i></button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>