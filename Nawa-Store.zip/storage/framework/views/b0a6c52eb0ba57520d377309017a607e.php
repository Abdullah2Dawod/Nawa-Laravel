<?php $__env->startSection('sub_title' , 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"><?php echo e($title); ?> </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('orders.trashed')); ?>" type="button" class="btn btn-danger p-2">Orders Trashed
                <i class="fas fa-trash-alt"></i></a>
        </div>
    </header>
    <hr>

    <div class="row">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(URL::current()); ?>" method="get" class="form-inline">
        <input type="text" name="search" class="form-control mb-2 mr-sm-2" value="<?php echo e(request('saerch')); ?>" placeholder="Search...">

        <select name="status" class="form-control mb-2 mr-sm-2">
            <option value="">Status</option>
            <?php $__currentLoopData = $status_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $kay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if(request('status') == $value): echo 'selected'; endif; ?>><?php echo e($kay); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="payment_status" class="form-control mb-2 mr-sm-2">
            <option value="">payment_status</option>
            <?php $__currentLoopData = $payment_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $kay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if(request('payment_status') == $value): echo 'selected'; endif; ?>><?php echo e($kay); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button type="submit" class="btn btn-success mb-2 mr-sm-2" style="border: none">Search</button>
    </form>
    <table class="table table-striped text-center mt-2" style="font-size: 15px !important">
        <thead>
            <tr class="table-dark">
                <th>Id</th>
                <th>F Name</th>
                <th>L Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>City</th>
                <th>Pl Code</th>
                <th>Province</th>
                <th>Cy Code</th>
                <th>Status</th>
                <th>Pay Status</th>
                <th>Total</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->customer_first_name); ?></td>
                    <td><?php echo e($order->customer_last_name); ?></td>
                    <td><?php echo e($order->customer_email); ?></td>
                    <td><?php echo e($order->customer_phone); ?></td>
                    <td><?php echo e($order->customer_address); ?></td>
                    <td><?php echo e($order->customer_city); ?></td>
                    <td><?php echo e($order->customer_postal_code); ?></td>
                    <td><?php echo e($order->customer_province); ?></td>
                    <td><?php echo e($order->customer_country_code); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->payment_status); ?></td>
                    <td><?php echo e($order->total); ?></td>


                    <td><a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn-sm btn btn-outline-secondary"><i
                                class="far fa-edit"></i< /a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i
                                    class="fas fa-trash"></i></button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>