<?php $__env->startSection('sub_title' , 'Trashed Category'); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"> Trashed Category </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('categories.index')); ?>" type="button" class="btn btn-info p-2">Category List
                <i class="fas fa-plus"></i></a>
        </div>
    </header>

    <div class="row">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <table class="table table-striped text-center">
        <thead>
            <tr class="table-dark">
                <th>Id</th>
                <th>Name</th>
                <th>Deleted At</th>
                <th>Restore</th>
                <th>Force Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->deleted_at); ?></td>
                    <td>
                        <form action="<?php echo e(route('categories.restore', $category->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-trash-restore"></i></button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('categories.force-delete', $category->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="fas fa-trash"></i></button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($categories->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/categories/trashed.blade.php ENDPATH**/ ?>