<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            You have Errors :
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>





    <form class="form" method="post" action="<?php echo e(route('profile.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="container mt-5 mb-5">
            <div class="card border-primary text-bg-primary mb-3">
                <div class="card-header">Header</div>

                <div class="row p-3">

                    <div class="col-3">
                        <div class="mb-3">
                            <label for="first_name">First Name</label>
                            <input name="first_name" class="form-control" type="text" placeholder="first Name"
                                value="<?php echo e(old('first_name', $user->profile->first_name)); ?>" required="required">
                        </div>
                        <div class="mb-3">
                            <label for="last_name">Last Name</label>
                            <input name="last_name" class="form-control" type="text" placeholder="last name"
                                value="<?php echo e(old('first_name', $user->profile->last_name)); ?>" required="required">
                        </div>

                        <div class="mb-3">
                            <label for="gender">Gender</label>
                            <?php $__currentLoopData = $gender_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id=""
                                        value="<?php echo e($value); ?>" <?php if($value == old('gender', $user->gender)): echo 'checked'; endif; ?>>
                                    <label class="form-check-label" for="<?php echo e($value); ?>">
                                        <?php echo e($label); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                    <div class="col-3">
                        <div class="mb-3">
                            <label for="email">Email</label>
                            <input name="email" class="form-control" type="email" placeholder="Your Email"
                                value="<?php echo e(old('email', $user->email)); ?>" required="required">
                        </div>

                        <div class="mb-3">
                            <label for="birthday">Birthday</label>
                            <input name="birthday" class="form-control" type="date" placeholder="birthday"
                                value="<?php echo e(old('birthday', $user->profile->birthday)); ?>" required="required">
                        </div>
                        <div class="mb-3">
                            <label for="street">Street</label>
                            <input name="street" class="form-control" type="text" placeholder="street"
                                value="<?php echo e(old('street', $user->profile->street)); ?>" required="required">
                        </div>

                    </div>

                    <div class="col-3">
                        <div class="mb-3">
                            <label for="city">City</label>
                            <input name="city" class="form-control" type="text" placeholder="Your City"
                                value="<?php echo e(old('city', $user->profile->city)); ?>" required="required">
                        </div>

                        <div class="mb-3">
                            <label for="province">Province</label>
                            <input name="province" class="form-control" type="text" placeholder="province"
                                value="<?php echo e(old('province', $user->profile->province)); ?>" required="required">
                        </div>

                        <div class="mb-3">
                            <label for="postal_code">Postal Code</label>
                            <input name="postal_code" class="form-control" type="text" placeholder="postal code"
                                value="<?php echo e(old('postal_code', $user->profile->postal_code)); ?>" required="required">
                        </div>

                    </div>

                    <div class="col-3">
                        <div class="mb-3">
                            <label for="country_code">Country Code</label>
                            <input name="country_code" class="form-control" type="text" placeholder="country code"
                                value="<?php echo e(old('country_code', $user->profile->country_code)); ?>" required="required">
                        </div>
                    </div>

                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/profile/edit.blade.php ENDPATH**/ ?>