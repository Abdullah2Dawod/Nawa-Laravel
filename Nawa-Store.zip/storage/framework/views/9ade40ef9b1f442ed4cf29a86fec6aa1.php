<?php $__env->startSection('content'); ?>
    <h2 class="mb-4 fs-3">New product</h2>

    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <?php echo $__env->make('admin.products._form', [
            'Submit' => 'Update Product',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>