<?php $__env->startSection('sub_title' , 'Trashed Orders'); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"> Trashed Category </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('orders.index')); ?>" type="button" class="btn btn-info p-2">Orders List
                <i class="fas fa-plus"></i></a>
        </div>
    </header>

    <div class="row">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <table class="table table-striped text-center mt-2" style="font-size: 15px !important">
        <thead>
            <tr class="table-dark">
                <th>Id</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>City</th>
                <th>Postal Code</th>
                <th>Province</th>
                <th>Country Code</th>
                <th>Status</th>
                <th>Payment Status</th>
                <th>Currency</th>
                <th>Total</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->customer_first_name); ?></td>
                    <td><?php echo e($order->customer_last_name); ?></td>
                    <td><?php echo e($order->customer_email); ?></td>
                    <td><?php echo e($order->customer_phone); ?></td>
                    <td><?php echo e($order->customer_address); ?></td>
                    <td><?php echo e($order->customer_city); ?></td>
                    <td><?php echo e($order->customer_postal_code); ?></td>
                    <td><?php echo e($order->customer_province); ?></td>
                    <td><?php echo e($order->customer_country_code); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->payment_status); ?></td>
                    <td><?php echo e($order->currency); ?></td>
                    <td><?php echo e($order->total); ?></td>


                    <td>
                        <form action="<?php echo e(route('orders.restore', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-trash-restore"></i></button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('orders.force-delete', $order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="fas fa-trash"></i></button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


    <?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/orders/trashed.blade.php ENDPATH**/ ?>