<?php $__env->startSection('sub_title', 'Trashed'); ?>

<?php $__env->startSection('content'); ?>
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"> Trashed Products </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('products.index')); ?>" type="button" class="btn btn-info p-2">product List
                <i class="fas fa-plus"></i></a>
        </div>
    </header>

    <div class="row">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <table class="table table-striped text-center">
        <thead>
            <tr class="table-dark">
                <th>Id</th>
                <th>Image</th>
                <th>Name</th>
                <th>Deleted At</th>
                <th>Restore</th>
                <th>Force Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <th>
                        <a href="<?php echo e($product->image_url); ?>">
                            <img src="<?php echo e($product->image_url); ?>" width="60" alt="">
                        </a>
                    </th>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->deleted_at); ?></td>
                    <td>
                        <form action="<?php echo e(route('products.restore', $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-trash-restore"></i></button>
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('products.force-delete', $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="fas fa-trash"></i></button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Projects\Nawa\Nawa-Store\resources\views/admin/products/trashed.blade.php ENDPATH**/ ?>